#-------------------------------------------------------------------------------
# Name:        Extract GNGGA
# Purpose: Extract GPS coordiantes from a GNGGA frame in an ascii file and compile them in an other csv file
# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
"""
Created on Mon Feb 13 10:02:13 2023

@author: Delta
"""

# importer le module pandas qui sert de traitement DataFrame et importation du fichier
import pandas as pd

# nom du fichier CSV
filename = "C:\\Users\\Delta\\Desktop\\AM\\Positions_GNGGA_20230607_AM.csv"

# lire le fichier CSV avec pandas
df = pd.read_csv(filename)

# extraire les colonnes souhaitées
cols = [1, 2, 4, 9, 11]
filtered_df = df.iloc[:, cols]

# afficher le nouveau DataFrame filtré
print(filtered_df)

filtered_df.to_csv("C:\\Users\\Delta\\Desktop\\AM\\Pos_GPS_20230607_AM.csv", index=False)