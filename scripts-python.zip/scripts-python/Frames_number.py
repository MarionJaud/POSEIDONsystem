#-------------------------------------------------------------------------------
# Name:        Extract frames
# Purpose: Extract frames from a video using frame number
# -*- coding: utf-8 -*-
# Disclaimer : for some reason unbeknownst to my person, the following code always never extract frames for the 2nd second of the video (number 24 to 47)
#-------------------------------------------------------------------------------
"""
Created on Wed Feb 15 03:45:18 2023

@author: Delta
"""

import cv2
import time
import os

def video_to_frames(input_loc, output_loc, frame_nums):
    """Function to extract specific frames from input video file
    and save them as separate frames in an output directory.
    Args:
        input_loc: Input video file.
        output_loc: Output directory to save the frames.
        frame_nums: List of frame numbers to extract.
    Returns:
        None
    """
    try:
        os.mkdir(output_loc)
    except OSError:
        pass
    # Log the time
    time_start = time.time()
    # Start capturing the feed
    cap = cv2.VideoCapture(input_loc)
    # Find the number of frames
    video_length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) - 1
    print ("Number of frames: ", video_length)
    count = 0
    print ("Converting video..\n")
    # Start converting the video
    for frame_num in frame_nums:
        # Set the position of the next frame to read
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_num)
        # Extract the frame
        ret, frame = cap.read()
        if not ret:
            continue
        # Write the result back to output location.
        cv2.imwrite(output_loc + "/%#05d.jpg" % (frame_num), frame)
        count += 1
    # Log the time again
    time_end = time.time()
    # Release the feed
    cap.release()
    # Print stats
    print ("Done extracting frames.\n%d frames extracted" % count)
    print ("It took %d seconds for conversion." % (time_end-time_start))
    print ("Extracted frames: ", frame_nums)

if __name__=="__main__":
    input_loc = 'C:\\Users\\Delta\\Desktop\\AM\\1G\\GX010001.mp4'
    output_loc = 'C:\\Users\\Delta\\Desktop\\AM\\Images_extraites\\1G'
    frame_nums = [1200,1224,1248,1272,1296,1320,1344,1368,1392,1416,1440,1464,1488,1512,1536,1560,1584,1608,1632,1656,1680,1704,1728,1752,1776,1800,1824,1848,1872,1896,1920,1944,1968,1992,2016,2040,2064,2088,2112,2136,2160,2184,2208,2232,2256,2280,2304,2328,2352,2376,2400,2424,2448,2472,2496,2520,2544,2568,2592,2616,2640,2664,2688,2712,2736,2760,2784,2808,2832,2856,2880,2904,2928,2952,2976,3000,3024,3048,3072,3096,3120,3144,3168,3192,3216,3240,3264,3288,3312,3336,3360,3384,3408,3432,3456,3480,3504,3528,3552,3576,3600,3624,3648,3672,3696,3720,3744,3768,3792,3816,3840,3864,3888,3912,3936,3960,3984,4008,4032,4056,4080,4104,4128,4152,4176,4200,4224,4248,4272,4296,4320,4344,4368,4392,4416,4440,4464,4488,4512,4536,4560,4584,4608,4632,4656,4680,4704,4728,4752,4776,4800,4824,4848,4872,4896,4920,4944,4968,4992,5016,5040,5064,5088,5112,5136,5160,5184,5208,5232,5256,5280,5304,5328,5352,5376,5400,5424,5448,5472,5496,5520,5544,5568,5592,5616,5640,5664,5688,5712,5736,5760,5784,5808,5832,5856,5880,5904,5928,5952,5976,6000,6024,6048,6072,6096,6120,6144,6168,6192,6216,6240,6264,6288,6312,6336,6360,6384,6408,6432,6456,6480,6504,6528,6552,6576,6600,6624,6648,6672,6696,6720,6744,6768,6792,6816,6840,6864,6888,6912,6936,6960,6984,7008,7032,7056,7080,7104,7128,7152,7176,7200,7224,7248,7272,7296,7320,7344,7368,7392,7416,7440,7464,7488,7512,7536,7560,7584,7608,7632,7656,7680,7704,7728,7752,7776,7800,7824,7848,7872,7896,7920,7944,7968,7992,8016,8040,8064,8088,8112,8136] # Exemple de liste de frames à extraire
    video_to_frames(input_loc, output_loc, frame_nums)