#-------------------------------------------------------------------------------
# Name:        Converting GPS Coordinates
# Purpose: Compute and correct the lat and long coordinates from Decimal Minute Degree (ubx format) to Decimal Degree (used by photogrammetric softwares)
# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
"""
Created on Tue May  9 10:12:49 2023

@author: Delta
"""
import csv

def convert_dmd2dd(number):
    number /= 100
    decimal = number - int(number)
    decimal *= 100
    decimal /= 60
    decimal = round(decimal, 8)
    return int(number) + decimal

with open('C:\\Users\\Delta\\Desktop\\AM\\Pos_GPS_20230607_AM_toto_backup.txt', 'r') as infile, open('C:\\Users\\Delta\\Desktop\\AM\\Pos_GPS_20230607_AM_toto.csv', 'w', newline='') as outfile:
    reader = csv.reader(infile)
    header = next(reader)
    
    writer = csv.writer(outfile)
    writer.writerow(header)
    
    for row in reader:
        updated_row = row.copy()
        for i in range(1, 3):
            number = float(row[i])
            updated_number = convert_dmd2dd(number)
            updated_row[i] = updated_number
        
        writer.writerow(updated_row)
